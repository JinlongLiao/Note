package io.github.jinlongliao.webcontrol;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

/**
 * @author liaojinlong
 * @since 2021/8/23 22:06
 */
@SpringBootApplication
public class WebControlApplication {

    public static void main(String[] args) {
        SpringApplication.run(WebControlApplication.class, args);
    }

}
