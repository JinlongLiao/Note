package io.github.jinlongliao.webcontrol.controller;

 import io.github.jinlongliao.webcontrol.util.RobotUtil;
 import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

 import java.awt.event.KeyEvent;
 import java.awt.image.BufferedImage;
import java.util.Arrays;

/**
 * @author liaojinlong
 * @since 2021/8/23 22:19
 */
@RestController
public class KeyController {
    static {

        System.setProperty("java.awt.headless", "false");
    }
    private static final String SPLIT = ";";

    /**
     * 执行 快捷键操作
     *
     * @param keyStr
     */
    @RequestMapping("/pressKeys")
    public void pressKeys(@RequestParam("keyStr") String keyStr) {
        int[] keys = Arrays.asList(keyStr.split(SPLIT)).stream()
                .map(a -> Integer.parseInt(a))
                .mapToInt(Integer::valueOf).toArray();

        RobotUtil.keyClick(KeyEvent.VK_ALT,KeyEvent.VK_META,KeyEvent.VK_LEFT);
        BufferedImage bufferedImage = RobotUtil.captureScreen();
     }
}
