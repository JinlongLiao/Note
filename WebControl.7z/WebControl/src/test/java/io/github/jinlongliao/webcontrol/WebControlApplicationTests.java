package io.github.jinlongliao.webcontrol;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class WebControlApplicationTests {

    @Test
    void contextLoads() {
    }

}
