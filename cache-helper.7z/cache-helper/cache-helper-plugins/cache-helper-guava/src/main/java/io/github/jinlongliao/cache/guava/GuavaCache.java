package io.github.jinlongliao.cache.guava;

import com.google.common.cache.Cache;
import com.google.common.cache.CacheBuilder;

import java.util.Map;
import java.util.concurrent.TimeUnit;

/**
 * 实际Guava存储数据
 *
 * @author liaojinlong
 * @since 2021/9/29 14:40
 */
public class GuavaCache<V> {
    private final Cache<String, V> cache;
    private final Map<String, V> mapCache;

    public GuavaCache(int maxSize, int expireTime, TimeUnit timeUnit) {
        final CacheBuilder<Object, Object> cacheBuilder = CacheBuilder.newBuilder()
                .maximumSize(maxSize)
                .initialCapacity(1 << 8);
        if (expireTime > 0) {
            cacheBuilder.expireAfterWrite(expireTime, timeUnit);
        }
        this.cache = cacheBuilder.build();
        mapCache = cache.asMap();
    }

    public V put(String key, V v) {
        final V v1 = mapCache.get(key);
        cache.put(key, v);
        return v1;
    }
    public void del(String key ) {
        cache.invalidate(key);
    }

    public Map<String, V> getMapCache() {
        return mapCache;
    }
}
