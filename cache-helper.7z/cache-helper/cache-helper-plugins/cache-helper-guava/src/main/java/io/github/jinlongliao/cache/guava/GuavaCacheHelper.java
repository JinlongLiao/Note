package io.github.jinlongliao.cache.guava;

import io.github.jinlongliao.cache.core.CacheHelperType;
import io.github.jinlongliao.cache.exception.UnSupportOperateException;
import io.github.jinlongliao.cache.impl.local.AbstractLocalCacheHelper;

import java.util.HashSet;
import java.util.Map;
import java.util.Set;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.TimeUnit;

/**
 * 基于Google Guava 实现
 *
 * @author liaojinlong
 * @since 2021/9/29 14:27
 */
public class GuavaCacheHelper<V> extends AbstractLocalCacheHelper<V> {
    private Map<String, GuavaCache<V>> allKeys;
    private Set<GuavaCache<V>> caches;

    public GuavaCacheHelper(int maxSize) {
        super(maxSize);
        this.allKeys = new ConcurrentHashMap<>(maxSize);
        this.caches = new HashSet<>(32);

    }

    @Override
    public V get(String key) {
        final GuavaCache<V> guavaCache = allKeys.get(key);
        return guavaCache == null ? null : guavaCache.getMapCache().get(key);
    }

    @Override
    public V set(String key, V value, int expire, TimeUnit timeUnit) {
        GuavaCache<V> cache;
        if (allKeys.containsKey(key)) {
            cache = allKeys.get(key);
        } else {
            cache = new GuavaCache<>(this.maxSize, expire, timeUnit);
            caches.add(cache);
            allKeys.put(key, cache);
        }
        return cache.put(key, value);
    }

    @Override
    public boolean expireKey(String key, int expire, TimeUnit timeUnit) {
        final GuavaCache<V> cache = allKeys.get(key);
        if (cache == null) {
            return false;
        }

        final V v = cache.getMapCache().get(key);
        if (v == null) {
            return false;
        }
        cache.del(key);
        this.set(key, v, expire, timeUnit);
        return true;
    }

    @Override
    public long getExpireTime(String key) {
        throw new UnSupportOperateException();
    }

    @Override
    public CacheHelperType getCacheHelperType() {
        return CacheHelperType.GUAVA;
    }

    @Override
    public int getLength() {
        int size = 0;
        for (GuavaCache<V> cache : caches) {
            size += cache.getMapCache().size();
        }
        return size;
    }

    @Override
    protected void checkLimit() {
        // TODO: 2021/9/29  nothing
    }
}
