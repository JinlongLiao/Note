package io.github.jinlongliao.cache.guava;

import org.junit.Assert;
import org.junit.Test;

import java.util.concurrent.TimeUnit;

public class GuavaCacheHelperTest {
    private GuavaCacheHelper<Object> helper = new GuavaCacheHelper<>(32);

    @Test
    public void expireTest() throws InterruptedException {
        helper.set("key1", 1);
        helper.set("key2", 1, 1, TimeUnit.SECONDS);
        Assert.assertTrue(helper.containKey("key1"));
        Assert.assertTrue(helper.containKey("key2"));
        Thread.sleep(2000);
        Assert.assertTrue(helper.containKey("key1"));
        Assert.assertFalse(helper.containKey("key2"));
    }
}
