package io.github.jinlongliao.cache.memcached;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import io.github.jinlongliao.cache.exception.CacheRootException;
import io.github.jinlongliao.cache.memcached.serial.JackSonSerializable;
import io.github.jinlongliao.cache.memcached.serial.dto.Data;
import net.rubyeye.xmemcached.*;
import net.rubyeye.xmemcached.auth.AuthInfo;
import net.rubyeye.xmemcached.buffer.BufferAllocator;
import net.rubyeye.xmemcached.exception.MemcachedException;
import net.rubyeye.xmemcached.impl.ReconnectRequest;
import net.rubyeye.xmemcached.networking.Connector;
import net.rubyeye.xmemcached.transcoders.Transcoder;
import net.rubyeye.xmemcached.utils.Protocol;

import java.io.IOException;
import java.lang.reflect.ParameterizedType;
import java.lang.reflect.Type;
import java.net.InetSocketAddress;
import java.util.Collection;
import java.util.List;
import java.util.Map;
import java.util.Queue;
import java.util.concurrent.TimeoutException;


/**
 * 基于JackJson 的数据序列化
 *
 * @author liaojinlong
 * @since 2021/9/30 11:40
 */
public class XMemcachedJsonClient implements MemcachedClient {
	private final MemcachedClient memcachedClient;
	private final ObjectMapper objectMapper;

	public XMemcachedJsonClient(MemcachedClient memcachedClient) {
		this(memcachedClient, new ObjectMapper());
	}

	public XMemcachedJsonClient(MemcachedClient memcachedClient, ObjectMapper objectMapper) {
		this.objectMapper = objectMapper;
		this.memcachedClient = memcachedClient;
		this.memcachedClient.setTranscoder(new JackSonSerializable(objectMapper));

	}

	public MemcachedClient getMemcachedClient() {
		return memcachedClient;
	}


	/**
	 * Set the merge factor,this factor determins how many 'get' commands would be merge to one
	 * multi-get command.default is 150
	 *
	 * @param mergeFactor
	 */
	@Override
	public void setMergeFactor(int mergeFactor) {
		memcachedClient.setMergeFactor(mergeFactor);
	}

	/**
	 * Get the connect timeout
	 */
	@Override
	public long getConnectTimeout() {
		return memcachedClient.getConnectTimeout();
	}

	/**
	 * Set the connect timeout,default is 1 minutes
	 *
	 * @param connectTimeout
	 */
	@Override
	public void setConnectTimeout(long connectTimeout) {
		memcachedClient.setConnectTimeout(connectTimeout);
	}

	/**
	 * return the session manager
	 *
	 * @return
	 */
	@Override
	public Connector getConnector() {
		return memcachedClient.getConnector();
	}

	/**
	 * Enable/Disable merge many get commands to one multi-get command.true is to enable it,false is
	 * to disable it.Default is true.Recommend users to enable it.
	 *
	 * @param optimizeGet
	 */
	@Override
	public void setOptimizeGet(boolean optimizeGet) {
		memcachedClient.setOptimizeGet(optimizeGet);
	}

	/**
	 * Enable/Disable merge many command's buffers to one big buffer fit socket's send buffer
	 * size.Default is true.Recommend true.
	 *
	 * @param optimizeMergeBuffer
	 */
	@Override
	public void setOptimizeMergeBuffer(boolean optimizeMergeBuffer) {
		memcachedClient.setOptimizeMergeBuffer(optimizeMergeBuffer);
	}

	/**
	 * @return
	 */
	@Override
	public boolean isShutdown() {
		return memcachedClient.isShutdown();
	}

	/**
	 * Aadd a memcached server,the thread call this method will be blocked until the connecting
	 * operations completed(success or fail)
	 *
	 * @param server host string
	 * @param port   port number
	 */
	@Override
	public void addServer(String server, int port) throws IOException {
		memcachedClient.addServer(server, port);
	}

	/**
	 * Add a memcached server,the thread call this method will be blocked until the connecting
	 * operations completed(success or fail)
	 *
	 * @param inetSocketAddress memcached server's socket address
	 */
	@Override
	public void addServer(InetSocketAddress inetSocketAddress) throws IOException {
		memcachedClient.addServer(inetSocketAddress);
	}

	/**
	 * Add many memcached servers.You can call this method through JMX or program
	 *
	 * @param hostList
	 */
	@Override
	public void addServer(String hostList) throws IOException {
		memcachedClient.addServer(hostList);
	}

	/**
	 * Get current server list.You can call this method through JMX or program
	 */
	@Override
	public List<String> getServersDescription() {
		return memcachedClient.getServersDescription();
	}

	/**
	 * Remove many memcached server
	 *
	 * @param hostList
	 */
	@Override
	public void removeServer(String hostList) {
		memcachedClient.removeServer(hostList);
	}

	/**
	 * Remove memcached server with the exact given address.
	 *
	 * @param address Resolved server address
	 */
	@Override
	public void removeServer(InetSocketAddress address) {
		memcachedClient.removeServer(address);
	}

	/**
	 * Set the nio's ByteBuffer Allocator,use SimpleBufferAllocator by default.
	 *
	 * @param bufferAllocator
	 * @return
	 */
	@Override
	@Deprecated
	public void setBufferAllocator(BufferAllocator bufferAllocator) {
		memcachedClient.setBufferAllocator(bufferAllocator);
	}

	/**
	 * Get value by key
	 *
	 * @param key        Key
	 * @param timeout    Operation timeout,if the method is not returned in this time,throw
	 *                   TimeoutException
	 * @param transcoder The value's transcoder
	 * @return
	 * @throws TimeoutException
	 * @throws InterruptedException
	 * @throws MemcachedException
	 */
	@Override
	public <T> T get(String key, long timeout, Transcoder<T> transcoder) throws TimeoutException, InterruptedException, MemcachedException {
		T t;
		Object obj = memcachedClient.get(key, timeout, transcoder);
		if (transcoder instanceof JackSonSerializable) {
			Data data = (Data) obj;
			try {
				t = objectMapper.readValue(data.getData(), getGenericClass(transcoder));
			} catch (JsonProcessingException e) {
				throw new CacheRootException(e);
			}

		} else {
			t = (T) obj;
		}
		return t;
	}

	private <T> Class<T> getGenericClass(Object transcoder) {
		Type type = ((ParameterizedType) transcoder.getClass().getGenericSuperclass()).getActualTypeArguments()[0];
		return (Class<T>) type;
	}

	@Override
	public <T> T get(String key, long timeout) throws TimeoutException, InterruptedException, MemcachedException {
		return (T) this.get(key, timeout, memcachedClient.getTranscoder());
	}

	@Override
	public <T> T get(String key, Transcoder<T> transcoder) throws TimeoutException, InterruptedException, MemcachedException {
		return memcachedClient.get(key, transcoder);
	}

	@Override
	public <T> T get(String key) throws TimeoutException, InterruptedException, MemcachedException {
		return this.get(key, memcachedClient.getOpTimeout());
	}

	/**
	 * Just like get,But it return a GetsResponse,include cas value for cas update.
	 *
	 * @param key        key
	 * @param timeout    operation timeout
	 * @param transcoder
	 * @return GetsResponse
	 * @throws TimeoutException
	 * @throws InterruptedException
	 * @throws MemcachedException
	 */
	@Override
	public <T> GetsResponse<T> gets(String key, long timeout, Transcoder<T> transcoder) throws TimeoutException, InterruptedException, MemcachedException {
		return memcachedClient.gets(key, timeout, transcoder);
	}

	/**
	 * @param key
	 * @return
	 * @throws TimeoutException
	 * @throws InterruptedException
	 * @throws MemcachedException
	 * @see #gets(String, long, Transcoder)
	 */
	@Override
	public <T> GetsResponse<T> gets(String key) throws TimeoutException, InterruptedException, MemcachedException {
		return memcachedClient.gets(key);
	}

	/**
	 * @param key
	 * @param timeout
	 * @return
	 * @throws TimeoutException
	 * @throws InterruptedException
	 * @throws MemcachedException
	 * @see #gets(String, long, Transcoder)
	 */
	@Override
	public <T> GetsResponse<T> gets(String key, long timeout) throws TimeoutException, InterruptedException, MemcachedException {
		return memcachedClient.gets(key, timeout);
	}

	/**
	 * @param key
	 * @param transcoder
	 * @return
	 * @throws TimeoutException
	 * @throws InterruptedException
	 * @throws MemcachedException
	 * @see #gets(String, long, Transcoder)
	 */
	@Override
	public <T> GetsResponse<T> gets(String key, Transcoder transcoder) throws TimeoutException, InterruptedException, MemcachedException {
		return memcachedClient.gets(key, transcoder);
	}

	/**
	 * Bulk get items
	 *
	 * @param keyCollections key collection
	 * @param opTimeout      opTimeout
	 * @param transcoder     Value transcoder
	 * @return Exists items map
	 * @throws TimeoutException
	 * @throws InterruptedException
	 * @throws MemcachedException
	 */
	@Override
	public <T> Map<String, T> get(Collection<String> keyCollections, long opTimeout, Transcoder<T> transcoder) throws TimeoutException, InterruptedException, MemcachedException {
		return memcachedClient.get(keyCollections, opTimeout, transcoder);
	}

	/**
	 * @param keyCollections
	 * @param transcoder
	 * @return
	 * @throws TimeoutException
	 * @throws InterruptedException
	 * @throws MemcachedException
	 * @see #get(Collection, long, Transcoder)
	 */
	@Override
	public <T> Map<String, T> get(Collection<String> keyCollections, Transcoder<T> transcoder) throws TimeoutException, InterruptedException, MemcachedException {
		return memcachedClient.get(keyCollections, transcoder);
	}

	/**
	 * @param keyCollections
	 * @return
	 * @throws TimeoutException
	 * @throws InterruptedException
	 * @throws MemcachedException
	 * @see #get(Collection, long, Transcoder)
	 */
	@Override
	public <T> Map<String, T> get(Collection<String> keyCollections) throws TimeoutException, InterruptedException, MemcachedException {
		return memcachedClient.get(keyCollections);
	}

	/**
	 * @param keyCollections
	 * @param timeout
	 * @return
	 * @throws TimeoutException
	 * @throws InterruptedException
	 * @throws MemcachedException
	 * @see #get(Collection, long, Transcoder)
	 */
	@Override
	public <T> Map<String, T> get(Collection<String> keyCollections, long timeout) throws TimeoutException, InterruptedException, MemcachedException {
		return memcachedClient.get(keyCollections, timeout);
	}

	/**
	 * Bulk gets items
	 *
	 * @param keyCollections key collection
	 * @param opTime         Operation timeout
	 * @param transcoder     Value transcoder
	 * @return Exists GetsResponse map
	 * @throws TimeoutException
	 * @throws InterruptedException
	 * @throws MemcachedException
	 * @see GetsResponse
	 */
	@Override
	public <T> Map<String, GetsResponse<T>> gets(Collection<String> keyCollections, long opTime, Transcoder<T> transcoder) throws TimeoutException, InterruptedException, MemcachedException {
		return memcachedClient.gets(keyCollections, opTime, transcoder);
	}

	/**
	 * @param keyCollections
	 * @return
	 * @throws TimeoutException
	 * @throws InterruptedException
	 * @throws MemcachedException
	 * @see #gets(Collection, long, Transcoder)
	 */
	@Override
	public <T> Map<String, GetsResponse<T>> gets(Collection<String> keyCollections) throws TimeoutException, InterruptedException, MemcachedException {
		return memcachedClient.gets(keyCollections);
	}

	/**
	 * @param keyCollections
	 * @param timeout
	 * @return
	 * @throws TimeoutException
	 * @throws InterruptedException
	 * @throws MemcachedException
	 * @see #gets(Collection, long, Transcoder)
	 */
	@Override
	public <T> Map<String, GetsResponse<T>> gets(Collection<String> keyCollections, long timeout) throws TimeoutException, InterruptedException, MemcachedException {
		return memcachedClient.gets(keyCollections, timeout);
	}

	/**
	 * @param keyCollections
	 * @param transcoder
	 * @return
	 * @throws TimeoutException
	 * @throws InterruptedException
	 * @throws MemcachedException
	 * @see #gets(Collection, long, Transcoder)
	 */
	@Override
	public <T> Map<String, GetsResponse<T>> gets(Collection<String> keyCollections, Transcoder<T> transcoder) throws TimeoutException, InterruptedException, MemcachedException {
		return memcachedClient.gets(keyCollections, transcoder);
	}

	/**
	 * Store key-value item to memcached
	 *
	 * @param key        stored key
	 * @param exp        An expiration time, in seconds. Can be up to 30 days. After 30 days, is treated as a
	 *                   unix timestamp of an exact date.
	 * @param value      stored data
	 * @param transcoder transocder
	 * @param timeout    operation timeout,in milliseconds
	 * @return boolean result
	 * @throws TimeoutException
	 * @throws InterruptedException
	 * @throws MemcachedException
	 */
	@Override
	public <T> boolean set(String key, int exp, T value, Transcoder<T> transcoder, long timeout) throws TimeoutException, InterruptedException, MemcachedException {
		return memcachedClient.set(key, exp, value, transcoder, timeout);
	}

	/**
	 * @param key
	 * @param exp
	 * @param value
	 * @see #set(String, int, Object, Transcoder, long)
	 */
	@Override
	public boolean set(String key, int exp, Object value) throws TimeoutException, InterruptedException, MemcachedException {
		return memcachedClient.set(key, exp, value);
	}

	/**
	 * @param key
	 * @param exp
	 * @param value
	 * @param timeout
	 * @see #set(String, int, Object, Transcoder, long)
	 */
	@Override
	public boolean set(String key, int exp, Object value, long timeout) throws TimeoutException, InterruptedException, MemcachedException {
		return memcachedClient.set(key, exp, value, timeout);
	}

	/**
	 * @param key
	 * @param exp
	 * @param value
	 * @param transcoder
	 * @see #set(String, int, Object, Transcoder, long)
	 */
	@Override
	public <T> boolean set(String key, int exp, T value, Transcoder<T> transcoder) throws TimeoutException, InterruptedException, MemcachedException {
		return memcachedClient.set(key, exp, value, transcoder);
	}

	/**
	 * Store key-value item to memcached,doesn't wait for reply
	 *
	 * @param key   stored key
	 * @param exp   An expiration time, in seconds. Can be up to 30 days. After 30 days, is treated as a
	 *              unix timestamp of an exact date.
	 * @param value stored data
	 * @throws TimeoutException
	 * @throws InterruptedException
	 * @throws MemcachedException
	 */
	@Override
	public void setWithNoReply(String key, int exp, Object value) throws InterruptedException, MemcachedException {
		memcachedClient.setWithNoReply(key, exp, value);
	}

	/**
	 * @param key
	 * @param exp
	 * @param value
	 * @param transcoder
	 * @throws InterruptedException
	 * @throws MemcachedException
	 * @see #setWithNoReply(String, int, Object, Transcoder)
	 */
	@Override
	public <T> void setWithNoReply(String key, int exp, T value, Transcoder<T> transcoder) throws InterruptedException, MemcachedException {
		memcachedClient.setWithNoReply(key, exp, value, transcoder);
	}

	/**
	 * Add key-value item to memcached, success only when the key is not exists in memcached.
	 *
	 * @param key
	 * @param exp        An expiration time, in seconds. Can be up to 30 days. After 30 days, is treated as a
	 *                   unix timestamp of an exact date.
	 * @param value
	 * @param transcoder
	 * @param timeout
	 * @return boolean result
	 * @throws TimeoutException
	 * @throws InterruptedException
	 * @throws MemcachedException
	 */
	@Override
	public <T> boolean add(String key, int exp, T value, Transcoder<T> transcoder, long timeout) throws TimeoutException, InterruptedException, MemcachedException {
		return memcachedClient.add(key, exp, value, transcoder, timeout);
	}

	/**
	 * @param key
	 * @param exp
	 * @param value
	 * @return
	 * @throws TimeoutException
	 * @throws InterruptedException
	 * @throws MemcachedException
	 * @see #add(String, int, Object, Transcoder, long)
	 */
	@Override
	public boolean add(String key, int exp, Object value) throws TimeoutException, InterruptedException, MemcachedException {
		return memcachedClient.add(key, exp, value);
	}

	/**
	 * @param key
	 * @param exp
	 * @param value
	 * @param timeout
	 * @return
	 * @throws TimeoutException
	 * @throws InterruptedException
	 * @throws MemcachedException
	 * @see #add(String, int, Object, Transcoder, long)
	 */
	@Override
	public boolean add(String key, int exp, Object value, long timeout) throws TimeoutException, InterruptedException, MemcachedException {
		return memcachedClient.add(key, exp, value, timeout);
	}

	/**
	 * @param key
	 * @param exp
	 * @param value
	 * @param transcoder
	 * @return
	 * @throws TimeoutException
	 * @throws InterruptedException
	 * @throws MemcachedException
	 * @see #add(String, int, Object, Transcoder, long)
	 */
	@Override
	public <T> boolean add(String key, int exp, T value, Transcoder<T> transcoder) throws TimeoutException, InterruptedException, MemcachedException {
		return memcachedClient.add(key, exp, value, transcoder);
	}

	/**
	 * Add key-value item to memcached, success only when the key is not exists in memcached.This
	 * method doesn't wait for reply.
	 *
	 * @param key
	 * @param exp   An expiration time, in seconds. Can be up to 30 days. After 30 days, is treated as a
	 *              unix timestamp of an exact date.
	 * @param value
	 * @return
	 * @throws TimeoutException
	 * @throws InterruptedException
	 * @throws MemcachedException
	 */
	@Override
	public void addWithNoReply(String key, int exp, Object value) throws InterruptedException, MemcachedException {
		memcachedClient.addWithNoReply(key, exp, value);
	}

	/**
	 * @param key
	 * @param exp
	 * @param value
	 * @param transcoder
	 * @throws InterruptedException
	 * @throws MemcachedException
	 * @see #addWithNoReply(String, int, Object, Transcoder)
	 */
	@Override
	public <T> void addWithNoReply(String key, int exp, T value, Transcoder<T> transcoder) throws InterruptedException, MemcachedException {
		memcachedClient.addWithNoReply(key, exp, value, transcoder);
	}

	/**
	 * Replace the key's data item in memcached,success only when the key's data item is exists in
	 * memcached.This method will wait for reply from server.
	 *
	 * @param key
	 * @param exp        An expiration time, in seconds. Can be up to 30 days. After 30 days, is treated as a
	 *                   unix timestamp of an exact date.
	 * @param value
	 * @param transcoder
	 * @param timeout
	 * @return boolean result
	 * @throws TimeoutException
	 * @throws InterruptedException
	 * @throws MemcachedException
	 */
	@Override
	public <T> boolean replace(String key, int exp, T value, Transcoder<T> transcoder, long timeout) throws TimeoutException, InterruptedException, MemcachedException {
		return memcachedClient.replace(key, exp, value, transcoder, timeout);
	}

	/**
	 * @param key
	 * @param exp
	 * @param value
	 * @return
	 * @throws TimeoutException
	 * @throws InterruptedException
	 * @throws MemcachedException
	 * @see #replace(String, int, Object, Transcoder, long)
	 */
	@Override
	public boolean replace(String key, int exp, Object value) throws TimeoutException, InterruptedException, MemcachedException {
		return memcachedClient.replace(key, exp, value);
	}

	/**
	 * @param key
	 * @param exp
	 * @param value
	 * @param timeout
	 * @return
	 * @throws TimeoutException
	 * @throws InterruptedException
	 * @throws MemcachedException
	 * @see #replace(String, int, Object, Transcoder, long)
	 */
	@Override
	public boolean replace(String key, int exp, Object value, long timeout) throws TimeoutException, InterruptedException, MemcachedException {
		return memcachedClient.replace(key, exp, value, timeout);
	}

	/**
	 * @param key
	 * @param exp
	 * @param value
	 * @param transcoder
	 * @return
	 * @throws TimeoutException
	 * @throws InterruptedException
	 * @throws MemcachedException
	 * @see #replace(String, int, Object, Transcoder, long)
	 */
	@Override
	public <T> boolean replace(String key, int exp, T value, Transcoder<T> transcoder) throws TimeoutException, InterruptedException, MemcachedException {
		return memcachedClient.replace(key, exp, value, transcoder);
	}

	/**
	 * Replace the key's data item in memcached,success only when the key's data item is exists in
	 * memcached.This method doesn't wait for reply from server.
	 *
	 * @param key
	 * @param exp   An expiration time, in seconds. Can be up to 30 days. After 30 days, is treated as a
	 *              unix timestamp of an exact date.
	 * @param value
	 * @throws TimeoutException
	 * @throws InterruptedException
	 * @throws MemcachedException
	 */
	@Override
	public void replaceWithNoReply(String key, int exp, Object value) throws InterruptedException, MemcachedException {
		memcachedClient.replaceWithNoReply(key, exp, value);
	}

	/**
	 * @param key
	 * @param exp
	 * @param value
	 * @param transcoder
	 * @throws InterruptedException
	 * @throws MemcachedException
	 * @see #replaceWithNoReply(String, int, Object, Transcoder)
	 */
	@Override
	public <T> void replaceWithNoReply(String key, int exp, T value, Transcoder<T> transcoder) throws InterruptedException, MemcachedException {
		memcachedClient.replaceWithNoReply(key, exp, value, transcoder);
	}

	/**
	 * @param key
	 * @param value
	 * @return
	 * @throws TimeoutException
	 * @throws InterruptedException
	 * @throws MemcachedException
	 * @see #append(String, Object, long)
	 */
	@Override
	public boolean append(String key, Object value) throws TimeoutException, InterruptedException, MemcachedException {
		return memcachedClient.append(key, value);
	}

	/**
	 * Append value to key's data item,this method will wait for reply
	 *
	 * @param key
	 * @param value
	 * @param timeout
	 * @return boolean result
	 * @throws TimeoutException
	 * @throws InterruptedException
	 * @throws MemcachedException
	 */
	@Override
	public boolean append(String key, Object value, long timeout) throws TimeoutException, InterruptedException, MemcachedException {
		return memcachedClient.append(key, value, timeout);
	}

	/**
	 * Append value to key's data item,this method doesn't wait for reply.
	 *
	 * @param key
	 * @param value
	 * @throws TimeoutException
	 * @throws InterruptedException
	 * @throws MemcachedException
	 */
	@Override
	public void appendWithNoReply(String key, Object value) throws InterruptedException, MemcachedException {
		memcachedClient.appendWithNoReply(key, value);
	}

	/**
	 * @param key
	 * @param value
	 * @return
	 * @throws TimeoutException
	 * @throws InterruptedException
	 * @throws MemcachedException
	 * @see #prepend(String, Object, long)
	 */
	@Override
	public boolean prepend(String key, Object value) throws TimeoutException, InterruptedException, MemcachedException {
		return memcachedClient.prepend(key, value);
	}

	/**
	 * Prepend value to key's data item in memcached.This method doesn't wait for reply.
	 *
	 * @param key
	 * @param value
	 * @param timeout
	 * @return boolean result
	 * @throws TimeoutException
	 * @throws InterruptedException
	 * @throws MemcachedException
	 */
	@Override
	public boolean prepend(String key, Object value, long timeout) throws TimeoutException, InterruptedException, MemcachedException {
		return memcachedClient.prepend(key, value, timeout);
	}

	/**
	 * Prepend value to key's data item in memcached.This method doesn't wait for reply.
	 *
	 * @param key
	 * @param value
	 * @return
	 * @throws TimeoutException
	 * @throws InterruptedException
	 * @throws MemcachedException
	 */
	@Override
	public void prependWithNoReply(String key, Object value) throws InterruptedException, MemcachedException {
		memcachedClient.prependWithNoReply(key, value);
	}

	/**
	 * @param key
	 * @param exp
	 * @param value
	 * @param cas
	 * @return
	 * @throws TimeoutException
	 * @throws InterruptedException
	 * @throws MemcachedException
	 * @see #cas(String, int, Object, Transcoder, long, long)
	 */
	@Override
	public boolean cas(String key, int exp, Object value, long cas) throws TimeoutException, InterruptedException, MemcachedException {
		return memcachedClient.cas(key, exp, value, cas);
	}

	/**
	 * Cas is a check and set operation which means "store this data but only if no one else has
	 * updated since I last fetched it."
	 *
	 * @param key
	 * @param exp        An expiration time, in seconds. Can be up to 30 days. After 30 days, is treated as a
	 *                   unix timestamp of an exact date.
	 * @param value
	 * @param transcoder
	 * @param timeout
	 * @param cas
	 * @return
	 * @throws TimeoutException
	 * @throws InterruptedException
	 * @throws MemcachedException
	 */
	@Override
	public <T> boolean cas(String key, int exp, T value, Transcoder<T> transcoder, long timeout, long cas) throws TimeoutException, InterruptedException, MemcachedException {
		return memcachedClient.cas(key, exp, value, transcoder, timeout, cas);
	}

	/**
	 * @param key
	 * @param exp
	 * @param value
	 * @param timeout
	 * @param cas
	 * @return
	 * @throws TimeoutException
	 * @throws InterruptedException
	 * @throws MemcachedException
	 * @see #cas(String, int, Object, Transcoder, long, long)
	 */
	@Override
	public boolean cas(String key, int exp, Object value, long timeout, long cas) throws TimeoutException, InterruptedException, MemcachedException {
		return memcachedClient.cas(key, exp, value, timeout, cas);
	}

	/**
	 * @param key
	 * @param exp
	 * @param value
	 * @param transcoder
	 * @param cas
	 * @return
	 * @throws TimeoutException
	 * @throws InterruptedException
	 * @throws MemcachedException
	 * @see #cas(String, int, Object, Transcoder, long, long)
	 */
	@Override
	public <T> boolean cas(String key, int exp, T value, Transcoder<T> transcoder, long cas) throws TimeoutException, InterruptedException, MemcachedException {
		return memcachedClient.cas(key, exp, value, transcoder, cas);
	}

	/**
	 * Cas is a check and set operation which means "store this data but only if no one else has
	 * updated since I last fetched it."
	 *
	 * @param key
	 * @param exp        An expiration time, in seconds. Can be up to 30 days. After 30 days, is treated as a
	 *                   unix timestamp of an exact date.
	 * @param operation  CASOperation
	 * @param transcoder object transcoder
	 * @return
	 * @throws TimeoutException
	 * @throws InterruptedException
	 * @throws MemcachedException
	 */
	@Override
	public <T> boolean cas(String key, int exp, CASOperation<T> operation, Transcoder<T> transcoder) throws TimeoutException, InterruptedException, MemcachedException {
		return memcachedClient.cas(key, exp, operation, transcoder);
	}

	/**
	 * cas is a check and set operation which means "store this data but only if no one else has
	 * updated since I last fetched it."
	 *
	 * @param key
	 * @param exp         An expiration time, in seconds. Can be up to 30 days. After 30 days, is treated as a
	 *                    unix timestamp of an exact date.
	 * @param getsReponse gets method's result
	 * @param operation   CASOperation
	 * @param transcoder
	 * @return
	 * @throws TimeoutException
	 * @throws InterruptedException
	 * @throws MemcachedException
	 */
	@Override
	public <T> boolean cas(String key, int exp, GetsResponse<T> getsReponse, CASOperation<T> operation, Transcoder<T> transcoder) throws TimeoutException, InterruptedException, MemcachedException {
		return memcachedClient.cas(key, exp, getsReponse, operation, transcoder);
	}

	/**
	 * @param key
	 * @param exp
	 * @param getsReponse
	 * @param operation
	 * @return
	 * @throws TimeoutException
	 * @throws InterruptedException
	 * @throws MemcachedException
	 * @see #cas(String, int, GetsResponse, CASOperation, Transcoder)
	 */
	@Override
	public <T> boolean cas(String key, int exp, GetsResponse<T> getsReponse, CASOperation<T> operation) throws TimeoutException, InterruptedException, MemcachedException {
		return memcachedClient.cas(key, exp, getsReponse, operation);
	}

	/**
	 * @param key
	 * @param getsResponse
	 * @param operation
	 * @return
	 * @throws TimeoutException
	 * @throws InterruptedException
	 * @throws MemcachedException
	 * @see #cas(String, int, GetsResponse, CASOperation, Transcoder)
	 */
	@Override
	public <T> boolean cas(String key, GetsResponse<T> getsResponse, CASOperation<T> operation) throws TimeoutException, InterruptedException, MemcachedException {
		return memcachedClient.cas(key, getsResponse, operation);
	}

	/**
	 * @param key
	 * @param exp
	 * @param operation
	 * @return
	 * @throws TimeoutException
	 * @throws InterruptedException
	 * @throws MemcachedException
	 * @see #cas(String, int, GetsResponse, CASOperation, Transcoder)
	 */
	@Override
	public <T> boolean cas(String key, int exp, CASOperation<T> operation) throws TimeoutException, InterruptedException, MemcachedException {
		return memcachedClient.cas(key, exp, operation);
	}

	/**
	 * @param key
	 * @param operation
	 * @return
	 * @throws TimeoutException
	 * @throws InterruptedException
	 * @throws MemcachedException
	 * @see #cas(String, int, GetsResponse, CASOperation, Transcoder)
	 */
	@Override
	public <T> boolean cas(String key, CASOperation<T> operation) throws TimeoutException, InterruptedException, MemcachedException {
		return memcachedClient.cas(key, operation);
	}

	/**
	 * @param key
	 * @param getsResponse
	 * @param operation
	 * @return
	 * @throws TimeoutException
	 * @throws InterruptedException
	 * @throws MemcachedException
	 */
	@Override
	public <T> void casWithNoReply(String key, GetsResponse<T> getsResponse, CASOperation<T> operation) throws TimeoutException, InterruptedException, MemcachedException {
		memcachedClient.casWithNoReply(key, getsResponse, operation);
	}

	/**
	 * cas noreply
	 *
	 * @param key
	 * @param exp
	 * @param getsReponse
	 * @param operation
	 * @throws TimeoutException
	 * @throws InterruptedException
	 * @throws MemcachedException
	 */
	@Override
	public <T> void casWithNoReply(String key, int exp, GetsResponse<T> getsReponse, CASOperation<T> operation) throws TimeoutException, InterruptedException, MemcachedException {
		memcachedClient.casWithNoReply(key, exp, getsReponse, operation);
	}

	/**
	 * @param key
	 * @param exp
	 * @param operation
	 * @throws TimeoutException
	 * @throws InterruptedException
	 * @throws MemcachedException
	 * @see #casWithNoReply(String, int, GetsResponse, CASOperation)
	 */
	@Override
	public <T> void casWithNoReply(String key, int exp, CASOperation<T> operation) throws TimeoutException, InterruptedException, MemcachedException {
		memcachedClient.casWithNoReply(key, exp, operation);
	}

	/**
	 * @param key
	 * @param operation
	 * @throws TimeoutException
	 * @throws InterruptedException
	 * @throws MemcachedException
	 * @see #casWithNoReply(String, int, GetsResponse, CASOperation)
	 */
	@Override
	public <T> void casWithNoReply(String key, CASOperation<T> operation) throws TimeoutException, InterruptedException, MemcachedException {
		memcachedClient.casWithNoReply(key, operation);
	}

	/**
	 * Delete key's data item from memcached.It it is not exists,return false.</br>
	 * time is the amount of time in seconds (or Unix time until</br>
	 * which) the client wishes the server to refuse "add" and "replace"</br>
	 * commands with this key. For this amount of item, the item is put into a</br>
	 * delete queue, which means that it won't possible to retrieve it by the</br>
	 * "get" command, but "add" and "replace" command with this key will also</br>
	 * fail (the "set" command will succeed, however). After the time passes,</br>
	 * the item is finally deleted from server memory. </br>
	 * <strong>Note: This method is deprecated,because memcached 1.4.0 remove the optional argument
	 * "time".You can still use this method on old version,but is not recommended.</strong>
	 *
	 * @param key
	 * @param time
	 * @throws InterruptedException
	 * @throws MemcachedException
	 */
	@Override
	@Deprecated
	public boolean delete(String key, int time) throws TimeoutException, InterruptedException, MemcachedException {
		return memcachedClient.delete(key, time);
	}

	/**
	 * Delete key's date item from memcached
	 *
	 * @param key
	 * @param opTimeout Operation timeout
	 * @return
	 * @throws TimeoutException
	 * @throws InterruptedException
	 * @throws MemcachedException
	 * @since 1.3.2
	 */
	@Override
	public boolean delete(String key, long opTimeout) throws TimeoutException, InterruptedException, MemcachedException {
		return memcachedClient.delete(key, opTimeout);
	}

	/**
	 * Delete key's date item from memcached only if its cas value is the same as what was read.
	 *
	 * @param key
	 * @param cas
	 * @param opTimeout Operation timeout
	 * @return
	 * @throws TimeoutException
	 * @throws InterruptedException
	 * @throws MemcachedException
	 * @cas cas on delete to make sure the key is deleted only if its value is same as what was read.
	 * @since 1.3.2
	 */
	@Override
	public boolean delete(String key, long cas, long opTimeout) throws TimeoutException, InterruptedException, MemcachedException {
		return memcachedClient.delete(key, cas, opTimeout);
	}

	/**
	 * Set a new expiration time for an existing item
	 *
	 * @param key       item's key
	 * @param exp       New expiration time, in seconds. Can be up to 30 days. After 30 days, is treated as
	 *                  a unix timestamp of an exact date.
	 * @param opTimeout operation timeout
	 * @return
	 * @throws TimeoutException
	 * @throws InterruptedException
	 * @throws MemcachedException
	 */
	@Override
	public boolean touch(String key, int exp, long opTimeout) throws TimeoutException, InterruptedException, MemcachedException {
		return memcachedClient.touch(key, exp, opTimeout);
	}

	/**
	 * Set a new expiration time for an existing item,using default opTimeout second.
	 *
	 * @param key item's key
	 * @param exp New expiration time, in seconds. Can be up to 30 days. After 30 days, is treated as
	 *            a unix timestamp of an exact date.
	 * @return
	 * @throws TimeoutException
	 * @throws InterruptedException
	 * @throws MemcachedException
	 */
	@Override
	public boolean touch(String key, int exp) throws TimeoutException, InterruptedException, MemcachedException {
		return memcachedClient.touch(key, exp);
	}

	/**
	 * Get item and set a new expiration time for it
	 *
	 * @param key       item's key
	 * @param newExp    New expiration time, in seconds. Can be up to 30 days. After 30 days, is treated
	 *                  as a unix timestamp of an exact date.
	 * @param opTimeout operation timeout
	 * @return
	 * @throws TimeoutException
	 * @throws InterruptedException
	 * @throws MemcachedException
	 */
	@Override
	public <T> T getAndTouch(String key, int newExp, long opTimeout) throws TimeoutException, InterruptedException, MemcachedException {
		return memcachedClient.getAndTouch(key, newExp, opTimeout);
	}

	/**
	 * Get item and set a new expiration time for it,using default opTimeout
	 *
	 * @param key
	 * @param newExp
	 * @return
	 * @throws TimeoutException
	 * @throws InterruptedException
	 * @throws MemcachedException
	 */
	@Override
	public <T> T getAndTouch(String key, int newExp) throws TimeoutException, InterruptedException, MemcachedException {
		return memcachedClient.getAndTouch(key, newExp);
	}

	/**
	 * Get all connected memcached servers's version.
	 *
	 * @return
	 * @throws TimeoutException
	 * @throws InterruptedException
	 * @throws MemcachedException
	 */
	@Override
	public Map<InetSocketAddress, String> getVersions() throws TimeoutException, InterruptedException, MemcachedException {
		return memcachedClient.getVersions();
	}

	/**
	 * "incr" are used to change data for some item in-place, incrementing it. The data for the item
	 * is treated as decimal representation of a 64-bit unsigned integer. If the current data value
	 * does not conform to such a representation, the commands behave as if the value were 0. Also,
	 * the item must already exist for incr to work; these commands won't pretend that a non-existent
	 * key exists with value 0; instead, it will fail.This method doesn't wait for reply.
	 *
	 * @param key
	 * @param delta
	 * @return the new value of the item's data, after the increment operation was carried out.
	 * @throws InterruptedException
	 * @throws MemcachedException
	 */
	@Override
	public long incr(String key, long delta) throws TimeoutException, InterruptedException, MemcachedException {
		return memcachedClient.incr(key, delta);
	}

	@Override
	public long incr(String key, long delta, long initValue) throws TimeoutException, InterruptedException, MemcachedException {
		return memcachedClient.incr(key, delta, initValue);
	}

	/**
	 * "incr" are used to change data for some item in-place, incrementing it. The data for the item
	 * is treated as decimal representation of a 64-bit unsigned integer. If the current data value
	 * does not conform to such a representation, the commands behave as if the value were 0. Also,
	 * the item must already exist for incr to work; these commands won't pretend that a non-existent
	 * key exists with value 0; instead, it will fail.This method doesn't wait for reply.
	 *
	 * @param key       key
	 * @param delta
	 * @param initValue initValue if the data is not exists.
	 * @param timeout   operation timeout
	 * @return
	 * @throws TimeoutException
	 * @throws InterruptedException
	 * @throws MemcachedException
	 */
	@Override
	public long incr(String key, long delta, long initValue, long timeout) throws TimeoutException, InterruptedException, MemcachedException {
		return memcachedClient.incr(key, delta, initValue, timeout);
	}

	/**
	 * "decr" are used to change data for some item in-place, decrementing it. The data for the item
	 * is treated as decimal representation of a 64-bit unsigned integer. If the current data value
	 * does not conform to such a representation, the commands behave as if the value were 0. Also,
	 * the item must already exist for decr to work; these commands won't pretend that a non-existent
	 * key exists with value 0; instead, it will fail.This method doesn't wait for reply.
	 *
	 * @param key
	 * @param delta
	 * @return the new value of the item's data, after the decrement operation was carried out.
	 * @throws InterruptedException
	 * @throws MemcachedException
	 */
	@Override
	public long decr(String key, long delta) throws TimeoutException, InterruptedException, MemcachedException {
		return memcachedClient.decr(key, delta);
	}

	/**
	 * @param key
	 * @param delta
	 * @param initValue
	 * @return
	 * @throws TimeoutException
	 * @throws InterruptedException
	 * @throws MemcachedException
	 * @see decr
	 */
	@Override
	public long decr(String key, long delta, long initValue) throws TimeoutException, InterruptedException, MemcachedException {
		return memcachedClient.decr(key, delta, initValue);
	}

	/**
	 * "decr" are used to change data for some item in-place, decrementing it. The data for the item
	 * is treated as decimal representation of a 64-bit unsigned integer. If the current data value
	 * does not conform to such a representation, the commands behave as if the value were 0. Also,
	 * the item must already exist for decr to work; these commands won't pretend that a non-existent
	 * key exists with value 0; instead, it will fail.This method doesn't wait for reply.
	 *
	 * @param key       The key
	 * @param delta
	 * @param initValue The initial value if the data is not exists.
	 * @param timeout   Operation timeout
	 * @return
	 * @throws TimeoutException
	 * @throws InterruptedException
	 * @throws MemcachedException
	 */
	@Override
	public long decr(String key, long delta, long initValue, long timeout) throws TimeoutException, InterruptedException, MemcachedException {
		return memcachedClient.decr(key, delta, initValue, timeout);
	}

	/**
	 * Make All connected memcached's data item invalid
	 *
	 * @throws TimeoutException
	 * @throws InterruptedException
	 * @throws MemcachedException
	 */
	@Override
	public void flushAll() throws TimeoutException, InterruptedException, MemcachedException {
		memcachedClient.flushAll();
	}

	@Override
	public void flushAllWithNoReply() throws InterruptedException, MemcachedException {
		memcachedClient.flushAllWithNoReply();
	}

	/**
	 * Make All connected memcached's data item invalid
	 *
	 * @param timeout operation timeout
	 * @throws TimeoutException
	 * @throws InterruptedException
	 * @throws MemcachedException
	 */
	@Override
	public void flushAll(long timeout) throws TimeoutException, InterruptedException, MemcachedException {
		memcachedClient.flushAll(timeout);
	}

	/**
	 * Invalidate all existing items immediately
	 *
	 * @param address Target memcached server
	 * @throws TimeoutException
	 * @throws InterruptedException
	 * @throws MemcachedException
	 */
	@Override
	public void flushAll(InetSocketAddress address) throws MemcachedException, InterruptedException, TimeoutException {
		memcachedClient.flushAll(address);
	}

	@Override
	public void flushAllWithNoReply(InetSocketAddress address) throws MemcachedException, InterruptedException {
		memcachedClient.flushAllWithNoReply(address);
	}

	@Override
	public void flushAll(InetSocketAddress address, long timeout) throws MemcachedException, InterruptedException, TimeoutException {
		memcachedClient.flushAll(address, timeout);
	}

	/**
	 * This method is deprecated,please use flushAll(InetSocketAddress) instead.
	 *
	 * @param host
	 * @throws TimeoutException
	 * @throws InterruptedException
	 * @throws MemcachedException
	 * @deprecated
	 */
	@Override
	@Deprecated
	public void flushAll(String host) throws TimeoutException, InterruptedException, MemcachedException {
		memcachedClient.flushAll(host);
	}

	@Override
	public Map<String, String> stats(InetSocketAddress address) throws MemcachedException, InterruptedException, TimeoutException {
		return memcachedClient.stats(address);
	}

	/**
	 * �ョ��瑰������emcached server缁��淇℃�
	 *
	 * @param address ����板�
	 * @param timeout ���瓒��
	 * @return
	 * @throws MemcachedException
	 * @throws InterruptedException
	 * @throws TimeoutException
	 */
	@Override
	public Map<String, String> stats(InetSocketAddress address, long timeout) throws MemcachedException, InterruptedException, TimeoutException {
		return memcachedClient.stats(address, timeout);
	}

	/**
	 * Get stats from all memcached servers
	 *
	 * @param timeout
	 * @return server->item->value map
	 * @throws MemcachedException
	 * @throws InterruptedException
	 * @throws TimeoutException
	 */
	@Override
	public Map<InetSocketAddress, Map<String, String>> getStats(long timeout) throws MemcachedException, InterruptedException, TimeoutException {
		return memcachedClient.getStats(timeout);
	}

	@Override
	public Map<InetSocketAddress, Map<String, String>> getStats() throws MemcachedException, InterruptedException, TimeoutException {
		return memcachedClient.getStats();
	}

	/**
	 * Get special item stats. "stats items" for example
	 *
	 * @param itemName@return
	 */
	@Override
	public Map<InetSocketAddress, Map<String, String>> getStatsByItem(String itemName) throws MemcachedException, InterruptedException, TimeoutException {
		return memcachedClient.getStatsByItem(itemName);
	}

	@Override
	public void shutdown() throws IOException {
		memcachedClient.shutdown();
	}

	@Override
	public boolean delete(String key) throws TimeoutException, InterruptedException, MemcachedException {
		return memcachedClient.delete(key);
	}

	/**
	 * return default transcoder,default is SerializingTranscoder
	 *
	 * @return
	 */
	@Override
	public Transcoder getTranscoder() {
		return memcachedClient.getTranscoder();
	}

	/**
	 * set transcoder
	 *
	 * @param transcoder
	 */
	@Override
	public void setTranscoder(Transcoder transcoder) {
		memcachedClient.setTranscoder(transcoder);
	}

	@Override
	public Map<InetSocketAddress, Map<String, String>> getStatsByItem(String itemName, long timeout) throws MemcachedException, InterruptedException, TimeoutException {
		return memcachedClient.getStatsByItem(itemName, timeout);
	}

	/**
	 * get operation timeout setting
	 *
	 * @return
	 */
	@Override
	public long getOpTimeout() {
		return memcachedClient.getOpTimeout();
	}

	/**
	 * set operation timeout,default is one second.
	 *
	 * @param opTimeout
	 */
	@Override
	public void setOpTimeout(long opTimeout) {
		memcachedClient.setOpTimeout(opTimeout);
	}

	@Override
	public Map<InetSocketAddress, String> getVersions(long timeout) throws TimeoutException, InterruptedException, MemcachedException {
		return memcachedClient.getVersions(timeout);
	}

	/**
	 * Returns available memcached servers list.This method is drepcated,please use
	 * getAvailableServers instead.
	 *
	 * @return
	 * @see #getAvailableServers()
	 */
	@Override
	@Deprecated
	public Collection<InetSocketAddress> getAvaliableServers() {
		return memcachedClient.getAvaliableServers();
	}

	/**
	 * Returns available memcached servers list.
	 *
	 * @return A available server collection
	 */
	@Override
	public Collection<InetSocketAddress> getAvailableServers() {
		return memcachedClient.getAvailableServers();
	}

	/**
	 * add a memcached server to MemcachedClient
	 *
	 * @param server
	 * @param port
	 * @param weight
	 * @throws IOException
	 */
	@Override
	public void addServer(String server, int port, int weight) throws IOException {
		memcachedClient.addServer(server, port, weight);
	}

	@Override
	public void addServer(InetSocketAddress inetSocketAddress, int weight) throws IOException {
		memcachedClient.addServer(inetSocketAddress, weight);
	}

	/**
	 * Delete key's data item from memcached.This method doesn't wait for reply. This method does not
	 * work on memcached 1.3 or later version.See
	 * <a href= 'http://code.google.com/p/memcached/issues/detail?id=3&q=delete%20noreply ' > i s s u
	 * e 3</a> </br>
	 * <strong>Note: This method is deprecated,because memcached 1.4.0 remove the optional argument
	 * "time".You can still use this method on old version,but is not recommended.</strong>
	 *
	 * @param key
	 * @param time
	 * @throws InterruptedException
	 * @throws MemcachedException
	 */
	@Override
	@Deprecated
	public void deleteWithNoReply(String key, int time) throws InterruptedException, MemcachedException {
		memcachedClient.deleteWithNoReply(key, time);
	}

	@Override
	public void deleteWithNoReply(String key) throws InterruptedException, MemcachedException {
		memcachedClient.deleteWithNoReply(key);
	}

	/**
	 * "incr" are used to change data for some item in-place, incrementing it. The data for the item
	 * is treated as decimal representation of a 64-bit unsigned integer. If the current data value
	 * does not conform to such a representation, the commands behave as if the value were 0. Also,
	 * the item must already exist for incr to work; these commands won't pretend that a non-existent
	 * key exists with value 0; instead, it will fail.This method doesn't wait for reply.
	 *
	 * @param key
	 * @param delta
	 * @throws InterruptedException
	 * @throws MemcachedException
	 */
	@Override
	public void incrWithNoReply(String key, long delta) throws InterruptedException, MemcachedException {
		memcachedClient.incrWithNoReply(key, delta);
	}

	/**
	 * "decr" are used to change data for some item in-place, decrementing it. The data for the item
	 * is treated as decimal representation of a 64-bit unsigned integer. If the current data value
	 * does not conform to such a representation, the commands behave as if the value were 0. Also,
	 * the item must already exist for decr to work; these commands won't pretend that a non-existent
	 * key exists with value 0; instead, it will fail.This method doesn't wait for reply.
	 *
	 * @param key
	 * @param delta
	 * @throws InterruptedException
	 * @throws MemcachedException
	 */
	@Override
	public void decrWithNoReply(String key, long delta) throws InterruptedException, MemcachedException {
		memcachedClient.decrWithNoReply(key, delta);
	}

	/**
	 * Set the verbosity level of the memcached's logging output.This method will wait for reply.
	 *
	 * @param address
	 * @param level   logging level
	 * @throws TimeoutException
	 * @throws InterruptedException
	 * @throws MemcachedException
	 */
	@Override
	public void setLoggingLevelVerbosity(InetSocketAddress address, int level) throws TimeoutException, InterruptedException, MemcachedException {
		memcachedClient.setLoggingLevelVerbosity(address, level);
	}

	/**
	 * Set the verbosity level of the memcached's logging output.This method doesn't wait for reply
	 * from server
	 *
	 * @param address memcached server address
	 * @param level   logging level
	 * @throws InterruptedException
	 * @throws MemcachedException
	 */
	@Override
	public void setLoggingLevelVerbosityWithNoReply(InetSocketAddress address, int level) throws InterruptedException, MemcachedException {
		memcachedClient.setLoggingLevelVerbosityWithNoReply(address, level);
	}

	/**
	 * Add a memcached client listener
	 *
	 * @param listener
	 */
	@Override
	public void addStateListener(MemcachedClientStateListener listener) {
		memcachedClient.addStateListener(listener);
	}

	/**
	 * Remove a memcached client listener
	 *
	 * @param listener
	 */
	@Override
	public void removeStateListener(MemcachedClientStateListener listener) {
		memcachedClient.removeStateListener(listener);
	}

	/**
	 * Get all current state listeners
	 *
	 * @return
	 */
	@Override
	public Collection<MemcachedClientStateListener> getStateListeners() {
		return memcachedClient.getStateListeners();
	}

	@Override
	public void flushAllWithNoReply(int exptime) throws InterruptedException, MemcachedException {
		memcachedClient.flushAllWithNoReply(exptime);
	}

	@Override
	public void flushAll(int exptime, long timeout) throws TimeoutException, InterruptedException, MemcachedException {
		memcachedClient.flushAll(exptime, timeout);
	}

	@Override
	public void flushAllWithNoReply(InetSocketAddress address, int exptime) throws MemcachedException, InterruptedException {
		memcachedClient.flushAllWithNoReply(address, exptime);
	}

	@Override
	public void flushAll(InetSocketAddress address, long timeout, int exptime) throws MemcachedException, InterruptedException, TimeoutException {
		memcachedClient.flushAll(address, timeout, exptime);
	}

	/**
	 * If the memcached dump or network error cause connection closed,xmemcached would try to heal the
	 * connection.The interval between reconnections is 2 seconds by default. You can change that
	 * value by this method.
	 *
	 * @param healConnectionInterval MILLISECONDS
	 */
	@Override
	public void setHealSessionInterval(long healConnectionInterval) {
		memcachedClient.setHealSessionInterval(healConnectionInterval);
	}

	/**
	 * If the memcached dump or network error cause connection closed,xmemcached would try to heal the
	 * connection.You can disable this behaviour by using this method:<br/>
	 * <code> client.setEnableHealSession(false); </code><br/>
	 * The default value is true.
	 *
	 * @param enableHealSession
	 * @since 1.3.9
	 */
	@Override
	public void setEnableHealSession(boolean enableHealSession) {
		memcachedClient.setEnableHealSession(enableHealSession);
	}

	/**
	 * Return the default heal session interval in milliseconds
	 *
	 * @return
	 */
	@Override
	public long getHealSessionInterval() {
		return memcachedClient.getHealSessionInterval();
	}

	@Override
	public Protocol getProtocol() {
		return memcachedClient.getProtocol();
	}

	/**
	 * Store all primitive type as string,defualt is false.
	 *
	 * @param primitiveAsString
	 */
	@Override
	public void setPrimitiveAsString(boolean primitiveAsString) {
		memcachedClient.setPrimitiveAsString(primitiveAsString);
	}

	/**
	 * In a high concurrent enviroment,you may want to pool memcached clients.But a xmemcached client
	 * has to start a reactor thread and some thread pools,if you create too many clients,the cost is
	 * very large. Xmemcached supports connection pool instreadof client pool.you can create more
	 * connections to one or more memcached servers,and these connections share the same reactor and
	 * thread pools,it will reduce the cost of system.
	 *
	 * @param poolSize pool size,default is one,every memcached has only one connection.
	 */
	@Override
	public void setConnectionPoolSize(int poolSize) {
		memcachedClient.setConnectionPoolSize(poolSize);
	}

	/**
	 * Whether to enable heart beat
	 *
	 * @param enableHeartBeat if true,then enable heartbeat,true by default
	 */
	@Override
	public void setEnableHeartBeat(boolean enableHeartBeat) {
		memcachedClient.setEnableHeartBeat(enableHeartBeat);
	}

	/**
	 * Enables/disables sanitizing keys by URLEncoding.
	 *
	 * @param sanitizeKey if true, then URLEncode all keys
	 */
	@Override
	public void setSanitizeKeys(boolean sanitizeKey) {
		memcachedClient.setSanitizeKeys(sanitizeKey);
	}

	@Override
	public boolean isSanitizeKeys() {
		return memcachedClient.isSanitizeKeys();
	}

	/**
	 * Get counter for key,and if the key's value is not set,then set it with 0.
	 *
	 * @param key
	 * @return
	 */
	@Override
	public Counter getCounter(String key) {
		return memcachedClient.getCounter(key);
	}

	/**
	 * Get counter for key,and if the key's value is not set,then set it with initial value.
	 *
	 * @param key
	 * @param initialValue
	 * @return
	 */
	@Override
	public Counter getCounter(String key, long initialValue) {
		return memcachedClient.getCounter(key, initialValue);
	}

	/**
	 * Get key iterator for special memcached server.You must known that the iterator is a snapshot
	 * for memcached all keys,it is not real-time.The 'stats cachedump" has length limitation,so
	 * iterator could not visit all keys if you have many keys.Your application should not be
	 * dependent on this feature.
	 *
	 * @param address
	 * @return
	 * @deprecated memcached 1.6.x will remove cachedump stats command,so this method will be removed
	 * in the future
	 */
	@Override
	@Deprecated
	public KeyIterator getKeyIterator(InetSocketAddress address) throws MemcachedException, InterruptedException, TimeoutException {
		return memcachedClient.getKeyIterator(address);
	}

	/**
	 * Configure auth info
	 *
	 * @param map Auth info map,key is memcached server address,and value is the auth info for the
	 *            key.
	 */
	@Override
	public void setAuthInfoMap(Map<InetSocketAddress, AuthInfo> map) {
		memcachedClient.setAuthInfoMap(map);
	}

	/**
	 * return current all auth info
	 *
	 * @return Auth info map,key is memcached server address,and value is the auth info for the key.
	 */
	@Override
	public Map<InetSocketAddress, AuthInfo> getAuthInfoMap() {
		return memcachedClient.getAuthInfoMap();
	}

	/**
	 * Retruns the AuthInfo for all server strings (hostname:port)
	 *
	 * @return A map of AuthInfos for server strings (hostname:port)
	 */
	@Override
	public Map<String, AuthInfo> getAuthInfoStringMap() {
		return memcachedClient.getAuthInfoStringMap();
	}

	/**
	 * "incr" are used to change data for some item in-place, incrementing it. The data for the item
	 * is treated as decimal representation of a 64-bit unsigned integer. If the current data value
	 * does not conform to such a representation, the commands behave as if the value were 0. Also,
	 * the item must already exist for incr to work; these commands won't pretend that a non-existent
	 * key exists with value 0; instead, it will fail.This method doesn't wait for reply.
	 *
	 * @param key
	 * @param delta
	 * @param initValue the initial value to be added when value is not found
	 * @param timeout
	 * @param exp       the initial vlaue expire time, in seconds. Can be up to 30 days. After 30 days, is
	 *                  treated as a unix timestamp of an exact date.
	 * @return
	 * @throws TimeoutException
	 * @throws InterruptedException
	 * @throws MemcachedException
	 */
	@Override
	public long decr(String key, long delta, long initValue, long timeout, int exp) throws TimeoutException, InterruptedException, MemcachedException {
		return memcachedClient.decr(key, delta, initValue, timeout, exp);
	}

	/**
	 * "incr" are used to change data for some item in-place, incrementing it. The data for the item
	 * is treated as decimal representation of a 64-bit unsigned integer. If the current data value
	 * does not conform to such a representation, the commands behave as if the value were 0. Also,
	 * the item must already exist for incr to work; these commands won't pretend that a non-existent
	 * key exists with value 0; instead, it will fail.This method doesn't wait for reply.
	 *
	 * @param key       key
	 * @param delta     increment delta
	 * @param initValue the initial value to be added when value is not found
	 * @param timeout   operation timeout
	 * @param exp       the initial vlaue expire time, in seconds. Can be up to 30 days. After 30 days, is
	 *                  treated as a unix timestamp of an exact date.
	 * @return
	 * @throws TimeoutException
	 * @throws InterruptedException
	 * @throws MemcachedException
	 */
	@Override
	public long incr(String key, long delta, long initValue, long timeout, int exp) throws TimeoutException, InterruptedException, MemcachedException {
		return memcachedClient.incr(key, delta, initValue, timeout, exp);
	}

	/**
	 * Return the cache instance name
	 *
	 * @return
	 */
	@Override
	public String getName() {
		return memcachedClient.getName();
	}

	/**
	 * Set cache instance name
	 *
	 * @param name
	 */
	@Override
	public void setName(String name) {
		memcachedClient.setName(name);
	}

	/**
	 * Returns reconnecting task queue,the queue is thread-safe and 'weakly consistent',but maybe you
	 * <strong>should not modify it</strong> at all.
	 *
	 * @return The reconnecting task queue,if the client has not been started,returns null.
	 */
	@Override
	public Queue<ReconnectRequest> getReconnectRequestQueue() {
		return memcachedClient.getReconnectRequestQueue();
	}

	/**
	 * Configure wheather to set client in failure mode.If set it to true,that means you want to
	 * configure client in failure mode. Failure mode is that when a memcached server is down,it would
	 * not taken from the server list but marked as unavailable,and then further requests to this
	 * server will be transformed to standby node if configured or throw an exception until it comes
	 * back up.
	 *
	 * @param failureMode true is to configure client in failure mode.
	 */
	@Override
	public void setFailureMode(boolean failureMode) {
		memcachedClient.setFailureMode(failureMode);
	}

	/**
	 * Returns if client is in failure mode.
	 *
	 * @return
	 */
	@Override
	public boolean isFailureMode() {
		return memcachedClient.isFailureMode();
	}

	/**
	 * Set a key provider for pre-processing keys before sending them to memcached.
	 *
	 * @param keyProvider
	 * @since 1.3.8
	 */
	@Override
	public void setKeyProvider(KeyProvider keyProvider) {
		memcachedClient.setKeyProvider(keyProvider);
	}

	/**
	 * Returns maximum number of timeout exception for closing connection.
	 *
	 * @return
	 */
	@Override
	public int getTimeoutExceptionThreshold() {
		return memcachedClient.getTimeoutExceptionThreshold();
	}

	/**
	 * Set maximum number of timeout exception for closing connection.You can set it to be a large
	 * value to disable this feature.
	 *
	 * @param timeoutExceptionThreshold
	 * @see #DEFAULT_MAX_TIMEOUTEXCEPTION_THRESHOLD
	 */
	@Override
	public void setTimeoutExceptionThreshold(int timeoutExceptionThreshold) {
		memcachedClient.setTimeoutExceptionThreshold(timeoutExceptionThreshold);
	}

	/**
	 * Invalidate all namespace under the namespace using the default operation timeout.
	 *
	 * @param ns the namespace
	 * @throws MemcachedException
	 * @throws InterruptedException
	 * @throws TimeoutException
	 * @since 1.4.2
	 */
	@Override
	public void invalidateNamespace(String ns) throws MemcachedException, InterruptedException, TimeoutException {
		memcachedClient.invalidateNamespace(ns);
	}

	/**
	 * Invalidate all items under the namespace.
	 *
	 * @param ns        the namespace
	 * @param opTimeout operation timeout in milliseconds.
	 * @throws MemcachedException
	 * @throws InterruptedException
	 * @throws TimeoutException
	 * @since 1.4.2
	 */
	@Override
	public void invalidateNamespace(String ns, long opTimeout) throws MemcachedException, InterruptedException, TimeoutException {
		memcachedClient.invalidateNamespace(ns, opTimeout);
	}

	/**
	 * Remove current namespace set for this memcached client.It must begin with
	 * {@link #beginWithNamespace(String)} method.
	 *
	 * @see #beginWithNamespace(String)
	 */
	@Override
	public void endWithNamespace() {
		memcachedClient.endWithNamespace();
	}

	/**
	 * set current namespace for following operations with memcached client.It must be ended with
	 * {@link #endWithNamespace()} method.For example:
	 *
	 * <pre>
	 * memcachedClient.beginWithNamespace(userId);
	 * try {
	 *   memcachedClient.set(&quot;username&quot;, 0, username);
	 *   memcachedClient.set(&quot;email&quot;, 0, email);
	 * } finally {
	 *   memcachedClient.endWithNamespace();
	 * }
	 * </pre>
	 *
	 * @param ns
	 * @see #endWithNamespace()
	 * @see #withNamespace(String, MemcachedClientCallable)
	 */
	@Override
	public void beginWithNamespace(String ns) {
		memcachedClient.beginWithNamespace(ns);
	}

	/**
	 * With the namespae to do something with current memcached client.All operations with memcached
	 * client done in callable will be under the namespace. {@link #beginWithNamespace(String)} and
	 * {@link #endWithNamespace()} will called around automatically. For example:
	 *
	 * <pre>
	 *   memcachedClient.withNamespace(userId,new MemcachedClientCallable<Void>{
	 *     public Void call(MemcachedClient client) throws MemcachedException,
	 * 	InterruptedException, TimeoutException{
	 *      client.set("username",0,username);
	 *      client.set("email",0,email);
	 *      return null;
	 *     }
	 *   });
	 *   //invalidate all items under the namespace.
	 *   memcachedClient.invalidateNamespace(userId);
	 * </pre>
	 *
	 * @param ns
	 * @param callable
	 * @return
	 * @see #beginWithNamespace(String)
	 * @see #endWithNamespace()
	 * @since 1.4.2
	 */
	@Override
	public <T> T withNamespace(String ns, MemcachedClientCallable<T> callable) throws MemcachedException, InterruptedException, TimeoutException {
		return memcachedClient.withNamespace(ns, callable);
	}
}
