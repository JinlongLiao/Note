package io.github.jinlongliao.cache.memcached.serial;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import io.github.jinlongliao.cache.exception.CacheRootException;
import io.github.jinlongliao.cache.memcached.serial.dto.Data;
import net.rubyeye.xmemcached.transcoders.CachedData;
import net.rubyeye.xmemcached.transcoders.PrimitiveTypeTranscoder;
import net.rubyeye.xmemcached.transcoders.SerializingTranscoder;

import java.io.IOException;

/**
 * 基于 FasterXml 实现序列化
 *
 * @author liaojinlong
 * @since 2021/9/29 20:02
 */
public class JackSonSerializable extends PrimitiveTypeTranscoder<Object> {
	private final ObjectMapper objectMapper;

	public JackSonSerializable(ObjectMapper objectMapper) {
		this.objectMapper = objectMapper;
	}

	@Override
	public CachedData encode(Object o) throws CacheRootException {
		try {
			final byte[] bytes = objectMapper.writeValueAsBytes(buildData(objectMapper.writeValueAsString(o)));
			return new CachedData(SerializingTranscoder.COMPRESSED, bytes);
		} catch (JsonProcessingException e) {
			throw new CacheRootException(e);
		}
	}

	private Data buildData(String json) {
		return new Data(json,"",true);
	}

	@Override
	public Object decode(CachedData d) {
		try {
			return objectMapper.readValue(d.getData(), Data.class);
		} catch (IOException e) {
			throw new CacheRootException(e);
		}
	}
}
