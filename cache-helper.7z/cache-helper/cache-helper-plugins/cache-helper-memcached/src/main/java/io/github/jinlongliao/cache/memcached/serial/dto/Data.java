package io.github.jinlongliao.cache.memcached.serial.dto;

/**
 * 保存包装的data
 *
 * @author liaojinlong
 * @since 2021/9/30 10:51
 */
public class Data {
	/**
	 * 原始数据
	 */
	private String data;
	/**
	 * 基本数据类型
	 */
	private String className;
	/**
	 * 是否为集合或数组
	 */
	private boolean array;

	public Data() {
	}

	public Data(String data, String className, boolean array) {
		this.data = data;
		this.className = className;
		this.array = array;
	}

	public String getData() {
		return data;
	}

	public void setData(String data) {
		this.data = data;
	}

	public String getClassName() {
		return className;
	}

	public void setClassName(String className) {
		this.className = className;
	}

	public boolean isArray() {
		return array;
	}

	public void setArray(boolean array) {
		this.array = array;
	}
}
