package io.github.jinlongliao.cache.memcached;

import java.io.Serializable;

public class Abc implements Serializable {
	public static final long serialVersionUID = 1L;
	private String name;
	private int age;

	public String getName() {
		return this.name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public int getAge() {
		return this.age;
	}

	public void setAge(int age) {
		this.age = age;
	}

	@Override
	public boolean equals(Object o) {
		if (this == o) return true;
		if (o == null || getClass() != o.getClass()) return false;

		Abc abc = (Abc) o;

		if (age != abc.age) return false;
		return name.equals(abc.name);
	}

	@Override
	public int hashCode() {
		int result = name.hashCode();
		result = 31 * result + age;
		return result;
	}
}
