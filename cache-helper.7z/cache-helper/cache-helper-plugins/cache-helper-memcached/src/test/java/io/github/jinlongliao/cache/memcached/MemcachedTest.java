package io.github.jinlongliao.cache.memcached;

import com.fasterxml.jackson.dataformat.yaml.YAMLMapper;
import net.rubyeye.xmemcached.MemcachedClient;
import net.rubyeye.xmemcached.XMemcachedClient;
import net.rubyeye.xmemcached.exception.MemcachedException;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.Objects;
import java.util.concurrent.TimeoutException;


public class MemcachedTest {
	private MemcachedClient memcachedClient;

	@Before
	public void init() throws IOException {
		final XMemcachedClient memcachedClient = new XMemcachedClient("127.0.0.1", 11211);
		// memcachedClient.setOpTimeout(2000);
		// memcachedClient.setPrimitiveAsString(true);
		// this.memcachedClient = new XMemcachedJsonClient(memcachedClient, new YAMLMapper());
		// this.memcachedClient = new XMemcachedJsonClient(memcachedClient);
		this.memcachedClient = memcachedClient;
	}

	@Test
	public void ClassTest() {
		final Class<? extends Object> aClass = Integer.TYPE;
		final Class<? extends Integer> aClass1 = new Integer(55462).getClass();
		Assert.assertTrue(aClass.isPrimitive());
		Assert.assertFalse(aClass1.isPrimitive());
	}

	public static final String KEY = "CACHED_1";

	@Test
	public void cacheTest() throws InterruptedException, TimeoutException, MemcachedException {
		List<Abc> abcs = new ArrayList<>(64);
		for (int i = 0; i < 50; i++) {

			final Abc value = new Abc();
			value.setAge(i);
			value.setName(i + "44454");
			abcs.add(value);
		}

		memcachedClient.set(KEY, 60 * 6 * 1000, abcs);
		final Object object = memcachedClient.get(KEY);
		Assert.assertTrue(Objects.equals(object, abcs));
	}

}
