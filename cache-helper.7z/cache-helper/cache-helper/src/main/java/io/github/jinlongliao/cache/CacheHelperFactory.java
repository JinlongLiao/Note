package io.github.jinlongliao.cache;

import io.github.jinlongliao.cache.core.CacheHelperType;
import io.github.jinlongliao.cache.core.ICacheHelper;

import java.util.Collections;
import java.util.Map;
import java.util.Set;
import java.util.concurrent.ConcurrentHashMap;

/**
 * 缓存操作实现的工厂类
 *
 * @author liaojinlong
 * @since 2021/9/27 18:25
 */
public class CacheHelperFactory {
    private static final Map<CacheHelperType, ICacheHelper<Object>> HELPER_CACHE = new ConcurrentHashMap<>(8);

    private static final class Tmp {
        static final CacheHelperFactory INSTANCE = new CacheHelperFactory();
    }

    public static CacheHelperFactory getInstance() {
        return Tmp.INSTANCE;
    }

    private CacheHelperFactory() {
    }

    public static void addCacheHelper(CacheHelperType key, ICacheHelper<Object> cacheHelper) {
        HELPER_CACHE.put(key, cacheHelper);
    }

    public static Set<CacheHelperType> getSupportCacheType() {
        return Collections.unmodifiableSet(HELPER_CACHE.keySet());
    }
}
