package io.github.jinlongliao.cache.core;

/**
 * 缓存实现的类型
 *
 * @author liaojinlong
 * @since 2021/9/27 18:13
 */
public interface CacheHelperType {
    /**
     * 基于自身实现
     */
    CacheHelperType LOCAL_DEFAULT = new CacheHelperType() {
    };
    /**
     * 基于Google guava的Cache 实现
     */
    CacheHelperType GUAVA = new CacheHelperType() {
    };
    /**
     * 基于 caffeine Cache 实现
     */
    CacheHelperType CAFFEINE = new CacheHelperType() {
    };
    /**
     * 基于 ehcache2 Cache 实现
     */
    CacheHelperType EHCACHE2 = new CacheHelperType() {
    };
    /**
     * 基于 ehcache3 Cache 实现
     */
    CacheHelperType EHCACHE3 = new CacheHelperType() {
    };
    /**
     * 基于 Spring 包装的Redis Cache 实现
     */
    CacheHelperType SPRING_REDIS = new CacheHelperType() {
    };
    /**
     * 包装形式-
     */
    CacheHelperType WRAPPER = new CacheHelperType() {
    };

}
