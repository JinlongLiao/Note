package io.github.jinlongliao.cache.core;

import java.util.concurrent.TimeUnit;

/**
 * 抽象公共缓存方法
 *
 * @author liaojinlong
 * @since 2021/9/27 17:41
 */
public interface ICacheHelper<V> {
    /**
     * 从缓存中获取数据信息
     *
     * @param key
     * @return /
     */
    V get(String key);

    /**
     * 从缓存中获取数据信息,并设置获取超时时间
     *
     * @param key
     * @param timeout
     * @param timeUnit
     * @return /
     */
    V get(String key, int timeout, TimeUnit timeUnit);

    /**
     * 缓存数据，有效期为最终实现的最大值
     *
     * @param key
     * @param value
     * @return /
     */
    V set(String key, V value);

    /**
     * 缓存数据，并设置其过期时间
     *
     * @param key
     * @param value
     * @param expire
     * @param timeUnit
     * @return /
     */
    V set(String key, V value, int expire, TimeUnit timeUnit);

    /**
     * 使缓存的数据立即过期
     *
     * @param key
     * @return /
     */
    boolean expireKey(String key);


    /**
     * 使缓存的数据立即过期
     *
     * @param key
     * @return /
     */
    boolean delete(String key);

    /**
     * 使缓存的数据在指定时间后过期
     *
     * @param key
     * @param expire
     * @param timeUnit
     * @return /
     */
    boolean expireKey(String key, int expire, TimeUnit timeUnit);

    /**
     * 获取指定key的剩余有效时间 时间单位 毫秒
     *
     * @param key
     * @return /
     */
    long getExpireTime(String key);

    /**
     * 从其他缓存中同步数据
     *
     * @param key
     * @param cacheHelper
     * @return /
     */
    V refresh(String key, ICacheHelper<V> cacheHelper);

    /**
     * 返回缓存使用的Class
     *
     * @return /
     */
    CacheHelperType getCacheHelperType();

    /**
     * 是否在缓存中
     * @param key
     * @return /
     */
    boolean containKey(String key);
}
