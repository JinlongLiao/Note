package io.github.jinlongliao.cache.exception;
/**
 * 根层的异常类型
 * @author liaojinlong
  * @since 2021/9/27 18:22
 */
public class CacheRootException extends RuntimeException{
    public CacheRootException() {
        super();
    }

    public CacheRootException(String message) {
        super(message);
    }

    public CacheRootException(String message, Throwable cause) {
        super(message, cause);
    }

    public CacheRootException(Throwable cause) {
        super(cause);
    }

    protected CacheRootException(String message, Throwable cause, boolean enableSuppression, boolean writableStackTrace) {
        super(message, cause, enableSuppression, writableStackTrace);
    }
}
