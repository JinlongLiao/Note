package io.github.jinlongliao.cache.exception;
/**
 * @author liaojinlong
  * @since 2021/9/28 15:52
 */
public class OutOfLimitSizeException extends CacheRootException{
    public OutOfLimitSizeException() {
        super();
    }

    public OutOfLimitSizeException(String message) {
        super(message);
    }

    public OutOfLimitSizeException(String message, Throwable cause) {
        super(message, cause);
    }

    public OutOfLimitSizeException(Throwable cause) {
        super(cause);
    }

    protected OutOfLimitSizeException(String message, Throwable cause, boolean enableSuppression, boolean writableStackTrace) {
        super(message, cause, enableSuppression, writableStackTrace);
    }
}
