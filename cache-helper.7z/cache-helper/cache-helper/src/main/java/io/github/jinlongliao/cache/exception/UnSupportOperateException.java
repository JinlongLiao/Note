package io.github.jinlongliao.cache.exception;

/**
 * 不支持操作异常
 *
 * @author liaojinlong
 * @since 2021/9/27 18:22
 */
public class UnSupportOperateException extends CacheRootException {
    public UnSupportOperateException() {
        super();
    }

    public UnSupportOperateException(String message) {
        super(message);
    }

    public UnSupportOperateException(String message, Throwable cause) {
        super(message, cause);
    }

    public UnSupportOperateException(Throwable cause) {
        super(cause);
    }

    protected UnSupportOperateException(String message, Throwable cause, boolean enableSuppression, boolean writableStackTrace) {
        super(message, cause, enableSuppression, writableStackTrace);
    }
}
