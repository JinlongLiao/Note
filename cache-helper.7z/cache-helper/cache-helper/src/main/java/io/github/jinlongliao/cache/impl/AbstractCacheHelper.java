package io.github.jinlongliao.cache.impl;

import io.github.jinlongliao.cache.core.ICacheHelper;

/**
 * @author liaojinlong
 * @since 2021/9/28 14:31
 */
public abstract class AbstractCacheHelper<V> implements ICacheHelper<V> {
    @Override
    public V refresh(String key, ICacheHelper<V> cacheHelper) {
        if (cacheHelper == null || this.equals(cacheHelper)) {
            return get(key);
        }
        final V v = cacheHelper.get(key);
        if (v == null) {
            this.expireKey(key);
        } else {
            this.set(key, v);
        }
        return v;
    }

    @Override
    public boolean expireKey(String key) {
        return delete(key);
    }
}
