package io.github.jinlongliao.cache.impl;

import io.github.jinlongliao.cache.core.ICacheHelper;
import io.github.jinlongliao.cache.strategy.SyncStrategy;


/**
 * @author liaojinlong
 * @since 2021/9/29 12:27
 */

public class CommonCachedHelper<V> extends WrapperCachedHelper<V> {

    public CommonCachedHelper(ICacheHelper<V> local, ICacheHelper<V> remote) {
        super(local, remote);
    }

    public CommonCachedHelper(boolean localFirst, ICacheHelper<V> local, ICacheHelper<V> remote, SyncStrategy<V> syncStrategy) {
        super(localFirst, local, remote, syncStrategy);
    }
}
