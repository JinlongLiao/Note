package io.github.jinlongliao.cache.impl;

import io.github.jinlongliao.cache.core.CacheHelperType;
import io.github.jinlongliao.cache.core.ICacheHelper;
import io.github.jinlongliao.cache.strategy.SyncStrategy;

import java.util.concurrent.TimeUnit;

/**
 * @author liaojinlong
 * @since 2021/9/29 12:28
 */
public abstract class WrapperCachedHelper<V> implements ICacheHelper<V> {
    private final boolean localFirst;
    private final ICacheHelper<V> local;
    private final ICacheHelper<V> remote;
    private final SyncStrategy<V> syncStrategy;

    public WrapperCachedHelper(ICacheHelper<V> local, ICacheHelper<V> remote) {
        this(true, local, remote, new SyncStrategy.DefaultSyncStrategy<V>());
    }

    public WrapperCachedHelper(boolean localFirst,
                               ICacheHelper<V> local,
                               ICacheHelper<V> remote,
                               SyncStrategy<V> syncStrategy) {
        this.localFirst = localFirst;
        this.local = local;
        this.remote = remote;
        this.syncStrategy = syncStrategy;
    }

    @Override
    public V get(String key) {
        return syncStrategy.sync(key, remote, local);
    }

    @Override
    public V get(String key, int timeout, TimeUnit timeUnit) {
        return syncStrategy.sync(key, remote, local);
    }

    @Override
    public V set(String key, V value) {

        return localFirst ? local.set(key, value) : remote.set(key, value);
    }

    @Override
    public V set(String key, V value, int expire, TimeUnit timeUnit) {
        return localFirst ? local.set(key, value, expire, timeUnit) : remote.set(key, value, expire, timeUnit);
    }

    @Override
    public boolean expireKey(String key) {
        return localFirst ? local.expireKey(key) : remote.expireKey(key);
    }

    @Override
    public boolean delete(String key) {
        return localFirst ? local.delete(key) : remote.delete(key);
    }

    @Override
    public boolean expireKey(String key, int expire, TimeUnit timeUnit) {
        return localFirst ? local.expireKey(key, expire, timeUnit) : remote.expireKey(key, expire, timeUnit);
    }

    @Override
    public long getExpireTime(String key) {
        return localFirst ? local.getExpireTime(key) : remote.getExpireTime(key);
    }

    @Override
    public V refresh(String key, ICacheHelper<V> cacheHelper) {
        remote.refresh(key, cacheHelper);
        return local.refresh(key, remote);
    }

    @Override
    public CacheHelperType getCacheHelperType() {
        return CacheHelperType.WRAPPER;
    }

    @Override
    public boolean containKey(String key) {
        boolean containKey = local.containKey(key);
        if (!containKey) {
            syncStrategy.sync(key, remote, local);
            containKey = local.containKey(key);
        }
        return containKey;
    }

}
