package io.github.jinlongliao.cache.impl.local;

import io.github.jinlongliao.cache.exception.OutOfLimitSizeException;
import io.github.jinlongliao.cache.impl.AbstractCacheHelper;

import java.util.concurrent.TimeUnit;


/**
 * @author liaojinlong
 * @since 2021/9/28 12:22
 */

public abstract class AbstractLocalCacheHelper<V> extends AbstractCacheHelper<V> {
    protected int maxSize;

    public AbstractLocalCacheHelper(int maxSize) {
        this.maxSize = maxSize;
    }

    @Override
    public V get(String key, int timeout, TimeUnit timeUnit) {
        return get(key);
    }

    @Override
    public V set(String key, V value) {
        return this.set(key, value, 0, TimeUnit.MILLISECONDS);
    }

    @Override
    public boolean delete(String key) {
        return expireKey(key, 0, TimeUnit.MILLISECONDS);
    }


    protected void checkLimit() {
        if (getLength() > maxSize) {
            throw new OutOfLimitSizeException("Out of MaxSize:" + maxSize);
        }
    }

    /**
     * 获取缓存的数目
     *
     * @return /
     */
    public abstract int getLength();

    @Override
    public boolean containKey(String key) {
        return get(key) != null;
    }

}
