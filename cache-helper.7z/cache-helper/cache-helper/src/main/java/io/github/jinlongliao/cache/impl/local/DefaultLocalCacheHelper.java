package io.github.jinlongliao.cache.impl.local;

import io.github.jinlongliao.cache.core.CacheHelperType;
import io.github.jinlongliao.cache.impl.local.model.ExpireModel;

import java.util.HashSet;
import java.util.Map;
import java.util.Set;
import java.util.concurrent.*;
import java.util.concurrent.atomic.AtomicInteger;

/**
 * 默认本地实现 基于JDK Map 实现
 *
 * @author liaojinlong
 * @since 2021/9/28 14:28
 */
public class DefaultLocalCacheHelper<V> extends AbstractLocalCacheHelper<V> {
    private ScheduledThreadPoolExecutor poolExecutor;
    private AtomicInteger size;
    /**
     * 永久不会过期的缓存
     */
    private Set<String> foreverKeys;
    private Set<String> allKeys;
    private Map<String, V> foreverCached;
    private Map<String, ExpireModel> expireCached;

    public DefaultLocalCacheHelper(int maxSize, int delay, TimeUnit timeUnit) {
        super(maxSize);
        this.expireCached = new ConcurrentHashMap<>(maxSize);
        this.foreverCached = new ConcurrentHashMap<>(maxSize);
        this.allKeys = new HashSet<>(maxSize, 0.75f);
        this.foreverKeys = new HashSet<>(maxSize, 0.75f);
        this.size = new AtomicInteger(0);
        poolExecutor = new ScheduledThreadPoolExecutor(1,
                new ThreadFactory() {
                    @Override
                    public Thread newThread(Runnable r) {
                        final Thread thread = new Thread(r);
                        thread.setName("DefaultLocalCacheHelper.CleaThread");
                        return thread;
                    }
                },
                new ThreadPoolExecutor.DiscardPolicy());
        Runtime.getRuntime().addShutdownHook(new Thread(new Runnable() {
            @Override
            public void run() {
                poolExecutor.shutdownNow();
            }
        }));
        this.expireCached = new ConcurrentHashMap<>(maxSize);
        this.startCleaThread(this, delay, timeUnit);
    }

    public DefaultLocalCacheHelper(int maxSize) {
        this(maxSize, 10, TimeUnit.SECONDS);
    }

    private void startCleaThread(DefaultLocalCacheHelper<V> helper, int delay, TimeUnit timeUnit) {

        helper.poolExecutor.scheduleWithFixedDelay(new Runnable() {
            @Override
            public void run() {
                final Map<String, ExpireModel> expireCached = helper.expireCached;
                Set<String> delKeys = new HashSet<>(16);
                final long timeMillis = System.currentTimeMillis();
                for (Map.Entry<String, ExpireModel> entry : expireCached.entrySet()) {
                    if (timeMillis > entry.getValue().getExpireTime()) {
                        delKeys.add(entry.getKey());
                    }
                }
                for (String delKey : delKeys) {
                    helper.delete(delKey);
                }
            }
        }, 0, delay, timeUnit);

    }

    @Override
    public int getLength() {
        return size.intValue();
    }

    public boolean hasRemoved(String key) {
        return allKeys.contains(key);
    }

    @Override
    public V get(String key) {
        if (!allKeys.contains(key)) {
            return null;
        }
        V tem = foreverCached.get(key);
        if (tem == null) {
            final ExpireModel expireModel = this.expireCached.get(key);
            if (expireModel != null) {
                final long expireTime = expireModel.getExpireTime();
                if (expireTime < System.currentTimeMillis()) {
                    this.expireKey(key);
                } else {
                    tem = (V) expireModel.getData();
                }
            }
        }
        return tem;
    }

    @Override
    public V set(String key, V value, int expire, TimeUnit timeUnit) {
        checkLimit();
        V old = value;
        if (!allKeys.contains(key)) {
            allKeys.add(key);
            size.incrementAndGet();
        }
        if (expire > 0) {
            final V remove = this.foreverCached.remove(key);
            if (remove != null) {
                old = remove;
            }
            final ExpireModel put = this.expireCached.put(key, new ExpireModel(System.currentTimeMillis() + timeUnit.toMillis(expire), value));
            if (put != null) {
                old = (V) put.getData();
            }
        } else {
            foreverKeys.add(key);
            final ExpireModel remove = this.expireCached.remove(key);
            if (remove != null) {
                old = (V) remove.getData();
            }
            final V put = this.foreverCached.put(key, value);
            if (put != null) {
                old = put;
            }
        }
        return old;
    }


    @Override
    public boolean expireKey(String key, int expire, TimeUnit timeUnit) {
        boolean res = this.allKeys.contains(key);
        if (res) {
            if (expire > 0) {
                final ExpireModel expireModel = this.expireCached.get(key);
                if (expireModel != null) {
                    expireModel.setExpireTime(System.currentTimeMillis() + timeUnit.toMillis(expire));
                }
            } else {
                this.size.decrementAndGet();
                this.allKeys.remove(key);
                this.foreverKeys.remove(key);
                this.expireCached.remove(key);
                this.foreverCached.remove(key);
            }
        }
        return false;
    }

    @Override
    public long getExpireTime(String key) {
        if (foreverKeys.contains(key)) {
            return 0;
        }
        final ExpireModel expireModel = expireCached.get(key);

        return expireModel == null ? -1 : expireModel.getExpireTime();
    }

    @Override
    public CacheHelperType getCacheHelperType() {
        return CacheHelperType.LOCAL_DEFAULT;
    }

    public Set<String> getForeverKeys() {
        return foreverKeys;
    }

    public Set<String> getAllKeys() {
        return allKeys;
    }
}
