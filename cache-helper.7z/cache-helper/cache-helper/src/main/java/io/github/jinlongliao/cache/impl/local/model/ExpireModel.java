package io.github.jinlongliao.cache.impl.local.model;

/**
 * 具有失效行的数据缓存模型
 *
 * @author liaojinlong
 * @since 2021/9/28 14:46
 */
public class ExpireModel {
    private long expireTime;
    private Object data;

    public ExpireModel(long expireTime, Object data) {
        this.expireTime = expireTime;
        this.data = data;
    }

    public void setExpireTime(long expireTime) {
        this.expireTime = expireTime;
    }

    public long getExpireTime() {
        return expireTime;
    }

    public Object getData() {
        return data;
    }
}
