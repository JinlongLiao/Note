package io.github.jinlongliao.cache.strategy;

import io.github.jinlongliao.cache.core.ICacheHelper;

import java.util.concurrent.TimeUnit;

/**
 * 两个数据缓存数据同步的策略
 *
 * @author liaojinlong
 * @since 2021/9/29 11:49
 */
public interface SyncStrategy<V> {
    /**
     * 两个缓存同步时业务实现
     *
     * @param key    缓存key
     * @param remote 远程缓存
     * @param local  本地缓存
     * @return 同步后获取的新值
     */
    V sync(String key, ICacheHelper<V> remote, ICacheHelper<V> local);

    class DefaultSyncStrategy<V> implements SyncStrategy<V> {

        @Override
        public V sync(String key, ICacheHelper<V> remote, ICacheHelper<V> local) {
            V v = local.get(key);
            if (v == null) {
                v = remote.get(key);
                final long expireTime = local.getExpireTime(key);
                if (expireTime < 0) {
                    // 不存在
                } else if (expireTime < 1) {
                    //永久
                    local.set(key, v);
                } else {
                    local.set(key, v, (int) (expireTime - System.currentTimeMillis()), TimeUnit.MILLISECONDS);
                }
            }
            return v;
        }
    }
}

