package io.github.jinlongliao.cache.impl.local;

import io.github.jinlongliao.cache.core.ICacheHelper;
import io.github.jinlongliao.cache.exception.OutOfLimitSizeException;
import org.junit.Assert;
import org.junit.Test;

import java.util.concurrent.TimeUnit;

public class DefaultLocalCacheHelperTest {
    private final ICacheHelper<Object> helper = new DefaultLocalCacheHelper<>(32, 1, TimeUnit.SECONDS);

    @Test
    public void expireTest() throws InterruptedException {
        helper.set("key1", 1);
        helper.set("key2", 1, 1, TimeUnit.SECONDS);
        Assert.assertTrue(helper.containKey("key1"));
        Assert.assertTrue(helper.containKey("key2"));
        Thread.sleep(2000);
        Assert.assertTrue(helper.containKey("key1"));
        Assert.assertFalse(helper.containKey("key2"));
    }

    @Test(expected = OutOfLimitSizeException.class)
    public void maxSizeTest() {
        final DefaultLocalCacheHelper<Integer> helper = new DefaultLocalCacheHelper<>(1);
        helper.set("key1", 1);
        helper.set("key2", 1);
        helper.set("key3", 1);

    }
}
