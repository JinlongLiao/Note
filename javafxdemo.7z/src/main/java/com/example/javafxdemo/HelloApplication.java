package com.example.javafxdemo;

import javafx.application.Application;
import javafx.fxml.FXMLLoader;
import javafx.scene.Scene;
import javafx.scene.text.Font;
import javafx.stage.Stage;
import sun.net.www.protocol.file.FileURLConnection;

import java.io.*;
import java.lang.reflect.Field;
import java.net.URL;
import java.util.List;
import java.util.stream.Collectors;

public class HelloApplication extends Application {
    public static final String mono = "JetBrains Mono";

    @Override
    public void start(Stage stage) throws IOException {
        initDefaultFont();
        FXMLLoader fxmlLoader = new FXMLLoader(HelloApplication.class.getResource("hello-view.fxml"));
        Scene scene = new Scene(fxmlLoader.load(), 320, 240);
        stage.setTitle("Hello!");
        stage.setScene(scene);
        stage.show();
    }

    private void initDefaultFont() {
        try {
            initFont("/ttf");
            Font font = Font.getDefault();
            Class<? extends Font> fontClass = font.getClass();
            Field fontClassField = fontClass.getDeclaredField("DEFAULT");
            fontClassField.setAccessible(true);
            fontClassField.set(font, Font.font(mono));
            fontClassField.setAccessible(false);
        } catch (Exception e) {
            e.printStackTrace();
        }

    }

    private void initFont(String path) throws IOException {
        URL resource = this.getClass().getResource(path);
        FileURLConnection fileURLConnection = (FileURLConnection) resource.openConnection();
        fileURLConnection.connect();
        InputStream inputStream = fileURLConnection.getInputStream();
        boolean isDir = isDir(inputStream);
        try {
            if (isDir) {
                loadDir(path, inputStream);
            } else {
                loadFile(path, inputStream);
            }
        } finally {
            fileURLConnection.close();
        }
    }

    private void loadFile(String path, InputStream inputStream) throws IOException {
        if (isDir(inputStream)) {
            loadDir(path, inputStream);
            return;
        }
        Font font = Font.loadFont(inputStream, 0);
    }

    private void loadDir(String path, InputStream inputStream) throws IOException {
        FileURLConnection con = null;
        InputStream inputstream = null;
        try {
            List<String> list = new BufferedReader(new InputStreamReader(inputStream)).lines().collect(Collectors.toList());
            for (String name : list) {
                String pathTem = path + File.separator + name;
                URL node = this.getClass().getResource(pathTem);
                con = (FileURLConnection) node.openConnection();
                con.connect();
                inputstream = con.getInputStream();
                if (isDir(inputstream)) {
                    loadDir(pathTem, inputstream);
                } else {
                    loadFile(pathTem, inputstream);
                }
            }
        } finally {
            if (inputstream != null) {
                inputstream.close();
            }

            if (con != null) {
                con.close();
            }
        }

    }

    private boolean isDir(InputStream inputStream) {
        return inputStream instanceof ByteArrayInputStream;
    }

    public static void main(String[] args) {
        launch();
    }
}